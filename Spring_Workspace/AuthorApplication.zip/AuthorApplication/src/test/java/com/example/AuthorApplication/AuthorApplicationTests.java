package com.example.AuthorApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorApplicationTests {

	@Test
	void contextLoads() {
	}

}
